كيف يمكننا الحصول على درجة كريم؟ إنها عملية من خطوتين.

أولاً، استخدم **الفهرس (`index`) لاختيار `الكائن`**. ثم، استخدم **ترميز النقطة (`dot notation`) للحصول على الخاصية (`property`)**.

```javascript
// students[1] تصل إلى الكائن الثاني
// { name: "Karim", grade: 92 }

// .grade تجلب قيمة الدرجة من ذلك الكائن
let karimsGrade = students[1].grade;

console.log(karimsGrade);
```

```
92
```

