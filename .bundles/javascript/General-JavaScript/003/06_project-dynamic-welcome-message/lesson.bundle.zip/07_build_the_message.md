لقد أصلحنا كل الأجزاء. حان الوقت الآن لتجميع كل شيء في خطوة أخيرة واحدة.

ها هي بيانات المستخدم مرة أخرى:
```javascript
let userName = "  fatima  ";
let city = "   jeddah  ";
let age = "25";
```

**مهمتك** هي كتابة الشيفرة التي تنتج هذه الرسالة بالضبط:
`Welcome, FATIMA from JEDDAH! In 5 years, you will be 30.`

فكر في استخدام القوالب النصية (`template literals`)، و`دوال النصوص` التي تدربنا عليها، و `parseInt()`.