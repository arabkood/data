## الجمع بين الدمج والتكرار

هنا يبدأ المرح الحقيقي! يمكنك الجمع بين العمليتين لإنشاء نصوص أكثر تعقيدًا:

```python
decoration = "=" * 5
title = "أهلاً بكم"
banner = decoration + " " + title + " " + decoration
print(banner)
# Prints: ===== أهلاً بكم =====
```

