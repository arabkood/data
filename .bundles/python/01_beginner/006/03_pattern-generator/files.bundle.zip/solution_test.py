import unittest
import subprocess
import sys
import os


class TestPatternGenerator(unittest.TestCase):
    """Test suite for the Pattern Generator Challenge."""

    @classmethod
    def setUpClass(cls):
        """Check if solution.py exists."""
        if not os.path.exists("solution.py"):
            raise FileNotFoundError(
                "solution.py not found. Please create your solution file."
            )

    def run_solution(self, pattern_type, size):
        """Run the solution with given inputs and return the output."""
        input_data = f"{pattern_type}\n{size}"

        try:
            result = subprocess.run(
                [sys.executable, "solution.py"],
                input=input_data,
                capture_output=True,
                text=True,
                timeout=10,
                encoding="utf-8",
            )

            if result.returncode != 0:
                self.fail(f"Program crashed with error:\n{result.stderr}")

            return result.stdout

        except subprocess.TimeoutExpired:
            self.fail("Program took too long to run (possible infinite loop)")

    def check_welcome_message(self, output):
        """Check if the welcome message and menu are displayed correctly."""
        required_texts = [
            "🎨 مرحباً بك في مولد الأنماط!",
            "اختر نوع النمط:",
            "1. مثلث من النجوم",
            "2. مثلث مقلوب من النجوم",
            "3. مثلث من الأرقام",
            "اختر رقم النمط (1-3):",
            "اختر حجم النمط (3-10):",
            "إليك النمط:",
        ]

        for text in required_texts:
            self.assertIn(text, output, f"Missing required text: '{text}'")

    def extract_pattern_lines(self, output):
        """Extract pattern lines from output."""
        lines = output.split("\n")

        # Find the line with "إليك النمط:" and get everything after it
        pattern_start_idx = -1
        for i, line in enumerate(lines):
            if "إليك النمط:" in line:
                pattern_start_idx = i + 1
                break

        if pattern_start_idx == -1:
            self.fail("Could not find pattern start marker")

        # Get pattern lines (non-empty lines after the marker)
        pattern_lines = []
        for line in lines[pattern_start_idx:]:
            if line.strip():  # Only non-empty lines
                pattern_lines.append(line)

        return pattern_lines

    def test_pattern1_size3(self):
        """Test Pattern 1 (star triangle) with size 3."""
        output = self.run_solution(1, 3)
        self.check_welcome_message(output)

        pattern_lines = self.extract_pattern_lines(output)
        expected = ["*", "**", "***"]

        self.assertEqual(
            pattern_lines,
            expected,
            f"\nExpected pattern:\n{chr(10).join(expected)}\n\nActual pattern:\n{chr(10).join(pattern_lines)}",
        )

    def test_pattern1_size5(self):
        """Test Pattern 1 (star triangle) with size 5."""
        output = self.run_solution(1, 5)
        self.check_welcome_message(output)

        pattern_lines = self.extract_pattern_lines(output)
        expected = ["*", "**", "***", "****", "*****"]

        self.assertEqual(
            pattern_lines,
            expected,
            f"\nExpected pattern:\n{chr(10).join(expected)}\n\nActual pattern:\n{chr(10).join(pattern_lines)}",
        )

    def test_pattern2_size4(self):
        """Test Pattern 2 (inverted star triangle) with size 4."""
        output = self.run_solution(2, 4)
        self.check_welcome_message(output)

        pattern_lines = self.extract_pattern_lines(output)
        expected = ["****", "***", "**", "*"]

        self.assertEqual(
            pattern_lines,
            expected,
            f"\nExpected pattern:\n{chr(10).join(expected)}\n\nActual pattern:\n{chr(10).join(pattern_lines)}",
        )

    def test_pattern2_size6(self):
        """Test Pattern 2 (inverted star triangle) with size 6."""
        output = self.run_solution(2, 6)
        self.check_welcome_message(output)

        pattern_lines = self.extract_pattern_lines(output)
        expected = ["******", "*****", "****", "***", "**", "*"]

        self.assertEqual(
            pattern_lines,
            expected,
            f"\nExpected pattern:\n{chr(10).join(expected)}\n\nActual pattern:\n{chr(10).join(pattern_lines)}",
        )

    def test_pattern3_size3(self):
        """Test Pattern 3 (number triangle) with size 3."""
        output = self.run_solution(3, 3)
        self.check_welcome_message(output)

        pattern_lines = self.extract_pattern_lines(output)
        expected = ["1", "12", "123"]

        self.assertEqual(
            pattern_lines,
            expected,
            f"\nExpected pattern:\n{chr(10).join(expected)}\n\nActual pattern:\n{chr(10).join(pattern_lines)}",
        )

    def test_pattern3_size7(self):
        """Test Pattern 3 (number triangle) with size 7."""
        output = self.run_solution(3, 7)
        self.check_welcome_message(output)

        pattern_lines = self.extract_pattern_lines(output)
        expected = ["1", "12", "123", "1234", "12345", "123456", "1234567"]

        self.assertEqual(
            pattern_lines,
            expected,
            f"\nExpected pattern:\n{chr(10).join(expected)}\n\nActual pattern:\n{chr(10).join(pattern_lines)}",
        )

    def test_edge_case_minimum_size(self):
        """Test with minimum allowed size (3)."""
        output = self.run_solution(1, 3)
        pattern_lines = self.extract_pattern_lines(output)
        self.assertEqual(
            len(pattern_lines), 3, "Pattern should have 3 lines for size 3"
        )

    def test_edge_case_maximum_size(self):
        """Test with maximum suggested size (10)."""
        output = self.run_solution(2, 10)
        pattern_lines = self.extract_pattern_lines(output)
        self.assertEqual(
            len(pattern_lines), 10, "Pattern should have 10 lines for size 10"
        )

        # Check first and last line for inverted pattern
        self.assertEqual(pattern_lines[0], "*" * 10, "First line should have 10 stars")
        self.assertEqual(pattern_lines[-1], "*", "Last line should have 1 star")

    def test_all_patterns_different_sizes(self):
        """Test all three patterns with different sizes to ensure variety."""
        test_cases = [
            (1, 4, ["*", "**", "***", "****"]),
            (2, 3, ["***", "**", "*"]),
            (3, 5, ["1", "12", "123", "1234", "12345"]),
        ]

        for pattern_type, size, expected in test_cases:
            with self.subTest(pattern=pattern_type, size=size):
                output = self.run_solution(pattern_type, size)
                pattern_lines = self.extract_pattern_lines(output)
                self.assertEqual(
                    pattern_lines,
                    expected,
                    f"Pattern {pattern_type} size {size} failed",
                )


if __name__ == "__main__":
    unittest.main(verbosity=2)
