اكتب دالة باسم `groupAndSum` تأخذ قائمة من القواميس، حيث كل قاموس يحتوي على `category` و `value`، وتُرجع قاموس يحتوي على مجموع القيم لكل فئة.

**المطلوب:**

- الدالة تأخذ معامل واحد: `items` (قائمة من القواميس)
- كل قاموس يحتوي على مفتاحين: `category` (نص) و `value` (رقم)
- الدالة تُرجع قاموس حيث المفاتيح هي الفئات والقيم هي مجموع القيم لكل فئة
- إذا كانت القائمة فارغة، أرجع قاموس فارغ

**مثال:**

```python
groupAndSum([{"category": "A", "value": 10}, {"category": "B", "value": 20}])
# {"A": 10, "B": 20}

groupAndSum([{"category": "A", "value": 10}, {"category": "A", "value": 5}])
# {"A": 15}

groupAndSum([{"category": "X", "value": 1}, {"category": "Y", "value": 2}, {"category": "X", "value": 3}])
# {"X": 4, "Y": 2}

groupAndSum([])
# {}
```
